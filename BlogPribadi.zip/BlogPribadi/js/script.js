var KAT_AWAL = ["Travelling", "Kuliner", "Skincare", "Catatan"];
var MAKS_KAT = 12;
var PALET = [["#ffb3a7", "#e4572e"], ["#c9f08f", "#5fa83a"], ["#ffc8f0", "#c85fb0"], ["#a0e7ff", "#3a8fc4"], ["#ffe28a", "#e0a020"], ["#d4b8ff", "#7a52d1"], ["#9ef0d0", "#2a9d8f"], ["#ffcba4", "#d9772b"]];
var WARNA = { Travelling: ["#92cdff", "#4a90e2"], Kuliner: ["#ffd96b", "#f08a24"], Skincare: ["#ff9ec0", "#d9548a"], Catatan: ["#86e3c8", "#2a9d8f"] };
var EMOJI = ["🌅", "🍳", "🧴", "☕", "🍜", "🎒", "📚", "🎬", "🌿", "💌"];
var AVATAR = ["🐱", "🐶", "🐰", "🐻", "🦊", "🐼", "🐸", "🦄"];
var KUNCI = "jh_data";

// ===== Data tulisan & profil (disimpan di browser) =====
var data = muat();
if (!Array.isArray(data.kategoriList)) data.kategoriList = KAT_AWAL.concat(Array.isArray(data.kategoriBaru) ? data.kategoriBaru : []);
delete data.kategoriBaru; delete data.sembunyikanContoh;
function daftarKat() { return data.kategoriList; }
function katAwal() { return data.kategoriList.indexOf("Catatan") >= 0 ? "Catatan" : data.kategoriList[0]; }
function semuaKat() { return ["Semua"].concat(daftarKat()); }
function warnaKat(nama) {
    if (WARNA[nama]) return WARNA[nama];
    var h = 0; for (var i = 0; i < nama.length; i++) h = (h * 31 + nama.charCodeAt(i)) % 997;
    return PALET[h % PALET.length];
}
function sw(nama) { return ' style="--warna:' + warnaKat(nama)[0] + '"'; }
function dekode(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }

function muat() {
    try { var d = JSON.parse(localStorage.getItem(KUNCI)); if (d && d.profil) return d; } catch (e) {}
    return { profil: { nama: "", email: "", bio: "", avatar: "🐱" }, artikel: [], kategoriList: KAT_AWAL.slice() };
}
function simpan() {
    try { localStorage.setItem(KUNCI, JSON.stringify(data)); return true; }
    catch (e) { toast("Penyimpanan browser penuh. Kurangi foto atau ekspor cadangan dulu."); return false; }
}
function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
}
function semua() {
    var u = data.artikel.slice().sort(function (a, b) { return b.waktu - a.waktu; });
    return u;
}
function cari(id) { return semua().find(function (x) { return x.id === id; }); }

// Merapikan data dari luar (impor / cloud) supaya aman ditampilkan
function rapikan(a) {
    var gambar = function (s) { return typeof s === "string" && /^data:image\/(jpeg|png|webp|gif);base64,/.test(s) ? s : ""; };
    return {
        id: String(a.id || "a" + Date.now()).replace(/[^\w-]/g, ""),
        milik: true,
        kategori: String(a.kategori || "Catatan").replace(/\s+/g, " ").trim().slice(0, 24) || "Catatan",
        judul: String(a.judul || "Tanpa judul").slice(0, 120),
        ringkas: String(a.ringkas || "").slice(0, 160),
        teks: String(a.teks || ""),
        emoji: EMOJI.indexOf(a.emoji) >= 0 ? a.emoji : "📝",
        foto: gambar(a.foto),
        fotoTambahan: (Array.isArray(a.fotoTambahan) ? a.fotoTambahan : []).map(gambar).filter(Boolean).slice(0, 6),
        audio: a.audio && a.audio.nama ? { nama: String(a.audio.nama).slice(0, 80) } : null,
        tanggal: String(a.tanggal || ""),
        waktu: Number(a.waktu) || Date.now(),
        diubah: Number(a.diubah) || Number(a.waktu) || Date.now()
    };
}
function bersih(o) { return JSON.parse(JSON.stringify(o)); }

// ===== Elemen halaman =====
var halaman = {
    beranda: document.getElementById("halamanBeranda"),
    artikel: document.getElementById("halamanArtikel"),
    tulis: document.getElementById("halamanTulis"),
    profil: document.getElementById("halamanProfil"),
    bantuan: document.getElementById("halamanBantuan")
};
var daftar = document.getElementById("daftarArtikel");
var isi = document.getElementById("isiArtikel");
var filter = document.getElementById("filter");
var judulDaftar = document.getElementById("judulDaftar");
var nav = document.getElementById("nav");
var isiProfil = document.getElementById("isiProfil");
var isiBantuan = document.getElementById("isiBantuan");

function toast(pesan) {
    var t = document.getElementById("toast");
    t.textContent = pesan; t.classList.add("tampil");
    clearTimeout(toast.w); toast.w = setTimeout(function () { t.classList.remove("tampil"); }, 3200);
}
function tandaiNav(k) {
    document.querySelectorAll(".nav a").forEach(function (l) { l.classList.toggle("aktif", l.getAttribute("data-kat") === k); });
}
function perbaruiNavProfil() {
    var p = data.profil;
    document.getElementById("navProfil").textContent = (p.avatar || "🐱") + " " + (p.nama ? p.nama.split(" ")[0] : "Profil");
}

// ===== Audio pengiring (disimpan di IndexedDB karena ukurannya besar) =====
function bukaDB(cb) {
    if (!window.indexedDB) return cb(new Error("IndexedDB tidak tersedia"));
    var r = indexedDB.open("jh_audio", 1);
    r.onupgradeneeded = function () { r.result.createObjectStore("audio"); };
    r.onsuccess = function () { cb(null, r.result); };
    r.onerror = function () { cb(r.error); };
}
function simpanAudio(id, blob, cb) {
    bukaDB(function (e, db) {
        if (e) return cb(e);
        var tx = db.transaction("audio", "readwrite"); tx.objectStore("audio").put(blob, id);
        tx.oncomplete = function () { cb(null); }; tx.onerror = function () { cb(tx.error); };
    });
}
function ambilAudio(id, cb) {
    bukaDB(function (e, db) {
        if (e) return cb(e);
        var q = db.transaction("audio").objectStore("audio").get(id);
        q.onsuccess = function () { cb(null, q.result); }; q.onerror = function () { cb(q.error); };
    });
}
function hapusAudio(id) { bukaDB(function (e, db) { if (!e) db.transaction("audio", "readwrite").objectStore("audio").delete(id); }); }

var audioAktif = null, tokenAudio = 0;
function hentikanAudio() {
    tokenAudio++;
    if (audioAktif) { audioAktif.au.pause(); audioAktif.au.src = ""; URL.revokeObjectURL(audioAktif.url); audioAktif = null; }
    halaman.artikel.classList.remove("dramatis"); document.body.classList.remove("drama-bg");
}
function pemutarHtml(a) {
    return '<div class="pemutar"><button class="tombol utama" id="btnPutar" aria-label="Putar atau jeda lagu">▶</button>' +
        '<div class="lagu"><b>🎵 ' + esc(a.audio.nama) + '</b><div class="bar" id="bar"><div id="isiBar"></div></div>' +
        '<span class="petunjuk" id="statusLagu">Tekan putar untuk mendengarkan sambil membaca.</span></div>' +
        '<div class="eq" id="eq"><i></i><i></i><i></i><i></i></div><button class="tombol kecil" id="btnDramatis">🎭 Mode dramatis: mati</button></div>';
}
function mulaiAudio(a) {
    var tok = tokenAudio, btn = document.getElementById("btnPutar"), bar = document.getElementById("bar"), isiBar = document.getElementById("isiBar"),
        eq = document.getElementById("eq"), dr = document.getElementById("btnDramatis"), status = document.getElementById("statusLagu"), dramaMati = false;
    function drama(on) {
        halaman.artikel.classList.toggle("dramatis", on); document.body.classList.toggle("drama-bg", on);
        dr.textContent = "🎭 Mode dramatis: " + (on ? "nyala" : "mati");
    }
    btn.disabled = true;
    ambilAudio(a.id, function (err, blob) {
        if (tok !== tokenAudio) return;
        if (err || !blob) { status.textContent = "File audio hanya tersimpan di perangkat tempat tulisan ini dibuat."; return; }
        var url = URL.createObjectURL(blob), au = new Audio(url);
        au.loop = true; audioAktif = { au: au, url: url }; btn.disabled = false;
        au.onplay = function () { eq.classList.add("main"); btn.textContent = "⏸"; if (!dramaMati) drama(true); };
        au.onpause = function () { eq.classList.remove("main"); btn.textContent = "▶"; };
        au.ontimeupdate = function () { if (au.duration) isiBar.style.width = (au.currentTime / au.duration * 100) + "%"; };
        au.onerror = function () { toast("Audio ini tidak bisa diputar di browser ini."); };
        btn.onclick = function () { if (au.paused) au.play().catch(function () { toast("Audio tidak bisa diputar. Coba tekan lagi."); }); else au.pause(); };
        dr.onclick = function () { var nyala = halaman.artikel.classList.contains("dramatis"); dramaMati = nyala; drama(!nyala); };
        bar.onclick = function (e) { var r = bar.getBoundingClientRect(); if (au.duration) au.currentTime = (e.clientX - r.left) / r.width * au.duration; };
    });
}

// ===== Foto =====
function buatFoto(a, kelas) {
    var w = a.milik ? warnaKat(a.kategori) : [a.c1, a.c2];
    var src = a.foto ? (a.foto.indexOf("data:") === 0 ? a.foto : "images/" + a.foto) : "";
    return '<div class="foto ' + (kelas || "") + '" style="--c1:' + w[0] + ';--c2:' + w[1] + '"><span class="emoji">' + esc(a.emoji) + '</span>' +
        (src ? '<img src="' + esc(src) + '" alt="' + esc(a.judul) + '" onerror="this.remove()">' : "") + "</div>";
}
// Mengecilkan foto supaya hemat tempat penyimpanan
function kecilkan(file, maks, cb) {
    var r = new FileReader();
    r.onload = function () {
        var img = new Image();
        img.onload = function () {
            var s = Math.min(1, maks / Math.max(img.width, img.height)), c = document.createElement("canvas");
            c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
            c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
            cb(c.toDataURL("image/jpeg", 0.7));
        };
        img.onerror = function () { toast("File itu bukan gambar yang bisa dibaca."); };
        img.src = r.result;
    };
    r.readAsDataURL(file);
}

// ===== Daftar artikel =====
function tampilDaftar(kat) {
    var hasil = semua().filter(function (a) { return kat === "Semua" || a.kategori === kat; });
    judulDaftar.textContent = kat === "Semua" ? "Artikel terbaru" : "Kategori: " + kat;
    daftar.innerHTML = hasil.length ? "" : '<p class="kosong">Belum ada artikel di sini. Yuk <a href="#tulis"><u>tulis yang pertama</u></a>, atau baca <a href="#bantuan"><u>Bantuan</u></a> dulu.</p>';
    hasil.forEach(function (a) {
        daftar.innerHTML += '<a class="kartu"' + sw(a.kategori) + ' href="#artikel/' + a.id + '">' + buatFoto(a) +
            '<div class="isi"><div class="meta"><span class="tag"' + sw(a.kategori) + '>' + esc(a.kategori) + "</span>" + esc(a.tanggal) + "</div>" +
            "<h3>" + esc(a.judul) + "</h3><p>" + esc(a.ringkas) + "</p></div></a>";
    });
    document.querySelectorAll(".chip").forEach(function (c) { c.classList.toggle("aktif", c.textContent === kat); });
    tandaiNav(kat === "Semua" ? "semua" : kat);
}

// ===== Isi artikel: teks biasa -> blok =====
function parseTeks(t) {
    var out = [], buf = [], lst = null;
    function tutupP() { if (buf.length) { out.push({ t: "p", x: buf.join(" ") }); buf = []; } }
    function tutupL() { if (lst) { out.push(lst); lst = null; } }
    t.split("\n").forEach(function (l) {
        l = l.trim();
        var m;
        if (!l) { tutupP(); tutupL(); }
        else if ((m = l.match(/^##\s+(.*)/))) { tutupP(); tutupL(); out.push({ t: "h", x: m[1] }); }
        else if ((m = l.match(/^[-*]\s+(.*)/))) { tutupP(); if (!lst || lst.t !== "ul") { tutupL(); lst = { t: "ul", items: [] }; } lst.items.push(m[1]); }
        else if ((m = l.match(/^\d+[.)]\s+(.*)/))) { tutupP(); if (!lst || lst.t !== "ol") { tutupL(); lst = { t: "ol", items: [] }; } lst.items.push(m[1]); }
        else { tutupL(); buf.push(l); }
    });
    tutupP(); tutupL();
    return out;
}
function renderBlok(b, a) {
    if (b.t === "p") return "<p>" + esc(b.x) + "</p>";
    if (b.t === "h") return "<h2>" + esc(b.x) + "</h2>";
    if (b.t === "ul" || b.t === "ol") return "<" + b.t + ">" + b.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</" + b.t + ">";
    if (b.t === "f") return '<figure><div class="foto" style="--c1:' + a.c2 + ";--c2:" + a.c1 + '"><span class="emoji">' + esc(b.e) + "</span></div><figcaption>" + esc(b.x) + "</figcaption></figure>";
    return "";
}

// ===== Bagikan tulisan lewat link (isi tulisan dimasukkan ke dalam link) =====
// Alamat dasar link bagikan: alamat website ini sendiri (bisa diganti lewat window.JH_BASE)
var BASE = window.JH_BASE || location.href.split("#")[0];
function keBase64Url(b) {
    var s = ""; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function dariBase64Url(t) {
    t = t.replace(/-/g, "+").replace(/_/g, "/"); while (t.length % 4) t += "=";
    var s = atob(t), b = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
    return b;
}
async function alirkan(bytes, Kelas) {
    var st = new Blob([bytes]).stream().pipeThrough(new Kelas("deflate-raw"));
    return new Uint8Array(await new Response(st).arrayBuffer());
}
async function buatLink(a) {
    var bytes = new TextEncoder().encode(JSON.stringify({ j: a.judul, k: a.kategori, e: a.emoji, r: a.ringkas, t: a.teks, d: a.tanggal, n: data.profil.nama || "" })), tag = "p";
    if (window.CompressionStream) { try { bytes = await alirkan(bytes, CompressionStream); tag = "z"; } catch (e) {} }
    return BASE + "#b." + tag + "." + keBase64Url(bytes);
}
async function bacaLink(token) {
    var m = token.match(/^b\.([pz])\.([\w-]+)$/); if (!m) return null;
    var bytes = dariBase64Url(m[2]);
    if (m[1] === "z") bytes = await alirkan(bytes, DecompressionStream);
    var o = JSON.parse(new TextDecoder().decode(bytes));
    var a = rapikan({ id: "bagikan", kategori: o.k, judul: o.j, ringkas: o.r, teks: o.t, emoji: o.e, tanggal: o.d });
    a.penulis = String(o.n || "").slice(0, 40);
    return a;
}
function salin(t, kotak) {
    function cadangan() {
        var ok = false; try { kotak.focus(); kotak.select(); ok = document.execCommand("copy"); } catch (e) {}
        toast(ok ? "Link disalin! Tinggal kirim ke temanmu 🎉" : "Salin manual dari kotak link ya.");
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { toast("Link disalin! Tinggal kirim ke temanmu 🎉"); }, cadangan);
    else cadangan();
}
async function tampilBagikan(token) {
    halaman.artikel.className = "artikel";
    isi.innerHTML = '<p class="info">Membuka tulisan...</p>';
    var a = null;
    try { a = await bacaLink(token); } catch (e) {}
    if (!a) { isi.innerHTML = '<p class="info">Link tulisan ini tidak valid atau terpotong. Minta pengirimnya membagikan ulang.</p>'; return; }
    halaman.artikel.className = "artikel"; halaman.artikel.style.setProperty("--warna", warnaKat(a.kategori)[0]);
    var html = '<div class="meta" style="margin-top:20px"><span class="tag"' + sw(a.kategori) + '>' + esc(a.kategori) + "</span>" + esc(a.tanggal) + (a.penulis ? " oleh " + esc(a.penulis) : "") + "</div>" +
        "<h1>" + esc(a.judul) + "</h1>" + buatFoto(a, "besar");
    parseTeks(a.teks).forEach(function (b) { html += renderBlok(b, a); });
    isi.innerHTML = html + '<p class="info">Tulisan ini dibagikan lewat Jejak Harian. <a href="#beranda"><u>Buat blogmu sendiri</u></a></p>';
    document.title = a.judul + " - Jejak Harian";
}

// ===== Halaman satu artikel =====
function tampilArtikel(id) {
    var a = cari(id);
    if (!a) { location.hash = "#beranda"; return; }
    var blok = parseTeks(a.teks);
    var html = '<div class="meta" style="margin-top:20px"><span class="tag"' + sw(a.kategori) + '>' + esc(a.kategori) + "</span>" + esc(a.tanggal) + "</div>" +
        "<h1>" + esc(a.judul) + "</h1>" + buatFoto(a, "besar") + (a.milik && a.audio ? pemutarHtml(a) : "");
    blok.forEach(function (b) { html += renderBlok(b, a); });
    (a.fotoTambahan || []).forEach(function (f) {
        html += '<figure><div class="foto"><img src="' + esc(f) + '" alt="Foto pendukung"></div></figure>';
    });
    html += '<button class="suka" id="suka">🤍 Suka tulisan ini</button>';
    if (a.milik) html += '<div class="aksi-milik"><a class="tombol" href="#tulis/' + a.id + '">✏️ Edit</a> <button class="tombol bahaya" id="hapusIni">🗑️ Hapus</button></div>';
    if (a.milik) html += '<div class="bagikan"><h2>Bagikan tulisan ini</h2><p class="petunjuk">Link berisi seluruh teks tulisan, jadi bisa dibuka siapa saja yang kamu kirimi. Foto dan audio tidak ikut terkirim.</p>' +
        '<button class="tombol utama" id="salinLink">🔗 Salin link tulisan</button><input id="linkBagi" readonly hidden aria-label="Link tulisan">' +
        '<p class="petunjuk" id="infoPanjang" hidden>Tulisannya panjang sehingga linknya juga panjang. Sebagian aplikasi chat bisa memotongnya, jadi coba buka linknya dulu sebelum dikirim.</p></div>';
    isi.innerHTML = html;
    halaman.artikel.className = "artikel"; halaman.artikel.style.setProperty("--warna", warnaKat(a.kategori)[0]);
    var tombol = document.getElementById("suka");
    tombol.onclick = function () {
        var aktif = tombol.classList.toggle("aktif");
        tombol.textContent = aktif ? "💖 Terima kasih!" : "🤍 Suka tulisan ini";
        tombol.classList.remove("pop"); void tombol.offsetWidth; tombol.classList.add("pop");
    };
    var sb = document.getElementById("salinLink");
    if (sb) sb.onclick = function () {
        buatLink(a).then(function (link) {
            var k = document.getElementById("linkBagi"); k.value = link; k.hidden = false;
            document.getElementById("infoPanjang").hidden = link.length < 6000;
            salin(link, k);
        }).catch(function () { toast("Gagal membuat link."); });
    };
    if (a.milik && a.audio) mulaiAudio(a);
    var hp = document.getElementById("hapusIni");
    if (hp) hp.onclick = function () { hapusArtikel(a.id, "#beranda"); };
    document.title = a.judul + " - Jejak Harian";
}

var armed = { k: "", t: 0 };
function konfirmasi(k) {
    if (armed.k === k && Date.now() - armed.t < 4000) { armed.k = ""; return true; }
    armed.k = k; armed.t = Date.now();
    toast("Klik Hapus sekali lagi untuk memastikan.");
    return false;
}
function hapusArtikel(id, tujuan) {
    if (!konfirmasi(id)) return;
    data.artikel = data.artikel.filter(function (x) { return x.id !== id; });
    simpan();
    hapusAudio(id);
    toast("Tulisan dihapus.");
    if (location.hash === tujuan) router(); else location.hash = tujuan;
}

// ===== Halaman tulis / edit =====
var tmp = { cover: "", extra: [] };
function tampilTulis(id) {
    var a = id ? data.artikel.find(function (x) { return x.id === id; }) : null;
    if (id && !a) { location.hash = "#tulis"; return; }
    document.getElementById("judulTulis").textContent = a ? "Edit tulisan" : "Tulis artikel baru";
    document.getElementById("fJudul").value = a ? a.judul : "";
    isiPilihanKat(a ? a.kategori : katAwal()); document.getElementById("panelKat").hidden = true;
    document.getElementById("fEmoji").value = a ? a.emoji : "📝";
    document.getElementById("fRingkas").value = a ? a.ringkas : "";
    document.getElementById("fTeks").value = a ? a.teks : "";
    document.getElementById("fCover").value = ""; document.getElementById("fExtra").value = "";
    tmp.cover = a ? a.foto : ""; tmp.extra = a ? a.fotoTambahan.slice() : [];
    tmp.audioBaru = null; tmp.audioHapus = false; tmp.audioAda = !!(a && a.audio);
    document.getElementById("fAudio").value = ""; document.getElementById("fAudioNama").value = a && a.audio ? a.audio.nama : "";
    document.getElementById("btnSimpan").setAttribute("data-id", a ? a.id : "");
    if (!a && draftAwal) {
        document.getElementById("fJudul").value = draftAwal.judul; document.getElementById("fRingkas").value = draftAwal.ringkas;
        document.getElementById("fTeks").value = draftAwal.teks; document.getElementById("fEmoji").value = draftAwal.emoji;
        draftAwal = null; toast("Draft contoh dimuat. Ubah sesukamu lalu simpan.");
    }
    pratinjauFoto();
    document.getElementById("infoLogin").innerHTML = "💡 Tulisan tersimpan otomatis di browser perangkat ini. Setelah terbit, bagikan lewat tombol Salin link.";
}
var katTerakhir = "Catatan";
function isiPilihanKat(pilih) {
    var s = document.getElementById("fKategori");
    if (daftarKat().indexOf(pilih) < 0) pilih = katAwal();
    s.innerHTML = daftarKat().map(function (k) { return '<option value="' + esc(k) + '">' + esc(k) + "</option>"; }).join("") + '<option value="__baru">➕ Tambah kategori baru...</option>';
    s.value = pilih; katTerakhir = pilih;
}
function tampilDaftarKat() {
    var h = "";
    data.kategoriList.forEach(function (k, i) {
        h += '<div class="baris item"><input class="katNama" data-i="' + i + '" value="' + esc(k) + '" maxlength="24" aria-label="Nama kategori">' +
            '<span><button type="button" class="tombol kecil" data-kat-aksi="ubah" data-i="' + i + '">Simpan nama</button> ' +
            '<button type="button" class="tombol kecil bahaya" data-kat-aksi="hapus" data-i="' + i + '"' + (data.kategoriList.length < 2 ? " disabled" : "") + '>Hapus</button></span></div>';
    });
    document.getElementById("daftarKat").innerHTML = h;
}
function namaKatValid(n, kecuali) {
    n = n.replace(/\s+/g, " ").trim();
    if (n.length < 2 || n.length > 24) { toast("Nama kategori harus 2 sampai 24 huruf."); return ""; }
    if (n.toLowerCase() === "semua" || daftarKat().some(function (x) { return x.toLowerCase() === n.toLowerCase() && x !== kecuali; })) { toast("Kategori itu sudah ada."); return ""; }
    return n;
}
function pratinjauAudio() {
    var nama = tmp.audioBaru ? tmp.audioBaru.name : (tmp.audioAda && !tmp.audioHapus ? "audio yang sudah tersimpan" : "");
    document.getElementById("pvAudio").innerHTML = nama ? '<span class="chip-audio">🎵 ' + esc(nama) + ' <button type="button" data-hapus="audio" aria-label="Hapus audio">✕</button></span>' : "";
}
function pratinjauFoto() {
    pratinjauAudio();
    document.getElementById("pvCover").innerHTML = tmp.cover ? '<img src="' + esc(tmp.cover) + '" alt="Foto sampul"><button type="button" data-hapus="cover">✕</button>' : "";
    document.getElementById("pvExtra").innerHTML = tmp.extra.map(function (f, i) {
        return '<div class="pv"><img src="' + esc(f) + '" alt="Foto tambahan"><button type="button" data-hapus="' + i + '">✕</button></div>';
    }).join("");
}
function simpanArtikel() {
    var judul = document.getElementById("fJudul").value.trim(), teks = document.getElementById("fTeks").value.trim();
    if (!judul || !teks) { toast("Judul dan isi tulisan harus diisi dulu ya."); return; }
    var id = document.getElementById("btnSimpan").getAttribute("data-id");
    var lama = id ? data.artikel.find(function (x) { return x.id === id; }) : null;
    var ringkas = document.getElementById("fRingkas").value.trim() || teks.replace(/[#*\-\n]+/g, " ").replace(/\s+/g, " ").slice(0, 110) + "...";
    var namaLagu = document.getElementById("fAudioNama").value.trim();
    var adaAudio = !!tmp.audioBaru || (tmp.audioAda && !tmp.audioHapus);
    if (!namaLagu && adaAudio) namaLagu = tmp.audioBaru ? tmp.audioBaru.name.replace(/\.[^.]+$/, "") : (lama && lama.audio ? lama.audio.nama : "Lagu pengiring");
    var a = rapikan({
        id: lama ? lama.id : "a" + Date.now(), kategori: document.getElementById("fKategori").value === "__baru" ? katAwal() : document.getElementById("fKategori").value, judul: judul, ringkas: ringkas, teks: teks,
        emoji: document.getElementById("fEmoji").value, foto: tmp.cover, fotoTambahan: tmp.extra, audio: adaAudio ? { nama: namaLagu } : null,
        tanggal: lama ? lama.tanggal : new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }),
        waktu: lama ? lama.waktu : Date.now(), diubah: Date.now()
    });
    data.artikel = data.artikel.filter(function (x) { return x.id !== a.id; });
    data.artikel.push(a);
    if (!simpan()) { data.artikel = data.artikel.filter(function (x) { return x.id !== a.id; }); if (lama) data.artikel.push(lama); return; }
    var selesai = function () { toast(lama ? "Perubahan disimpan!" : "Tulisan terbit! Klik Salin link untuk membagikannya 🎉"); location.hash = "#artikel/" + a.id; };
    if (tmp.audioBaru) simpanAudio(a.id, tmp.audioBaru, function (err) {
        if (err) { a.audio = null; simpan(); toast("Audio gagal disimpan, tulisannya tetap tersimpan."); }
        selesai();
    });
    else { if (tmp.audioHapus || !a.audio) hapusAudio(a.id); selesai(); }
}

// ===== Bantuan & draft contoh =====
var DRAFT = {
    judul: "Hari pertama menulis di Jejak Harian",
    ringkas: "Contoh tulisan sekaligus panduan singkat memakai Jejak Harian.",
    emoji: "📝",
    teks: "Halo! Ini contoh tulisan pertamaku di Jejak Harian. Tulisan ini sengaja dibuat sebagai contoh supaya aku tahu cara memakai semua fiturnya. Kalau sudah paham, tinggal hapus isinya lalu ganti dengan ceritaku sendiri.\n\n" +
        "## Cara menulis\nParagraf dipisah dengan satu baris kosong, seperti yang sedang kamu baca sekarang. Subjudul diawali tanda ## dan spasi.\n\n" +
        "## Daftar poin dan daftar angka\n- Awali baris dengan tanda strip untuk daftar poin\n- Cocok untuk catatan belanja atau daftar tempat\n\n" +
        "1. Awali baris dengan angka dan titik untuk langkah berurutan\n2. Cocok untuk resep atau tutorial\n3. Nomornya dirapikan otomatis\n\n" +
        "## Foto dan lagu\nFoto sampul dan foto pendukung ditambahkan lewat kolom unggah di bawah isi tulisan. Kalau ada lagu yang cocok dengan suasana ceritaku, aku bisa menambahkannya di kolom audio, lalu menyalakan mode dramatis saat membaca.\n\n" +
        "## Setelah terbit\nTulisan ini bisa dibagikan lewat tombol Salin link, diedit kapan saja, atau dihapus kalau sudah tidak diperlukan."
};
var draftAwal = null;
function bantuanHtml() {
    return '<h1>📖 Bantuan</h1><p class="meta">Panduan singkat memakai Jejak Harian, dari menulis sampai membagikan.</p>' +
        '<div class="baris"><a class="tombol utama" href="#tulis">✏️ Mulai menulis</a> <a class="tombol" href="#profil">👤 Buka profil</a></div>' +
        '<div class="kotak bantuan"><h2>Panduan</h2>' +
        '<details open><summary>1. Menulis tulisan pertama</summary><p>Buka menu <b>✏️ Tulis</b>, isi judul, pilih kategori, lalu tulis ceritamu. Klik <b>Simpan tulisan</b> dan tulisanmu langsung terbit di beranda.</p></details>' +
        '<details><summary>2. Merapikan isi tulisan</summary><p>Pisahkan paragraf dengan satu baris kosong. Awali baris dengan <code>## </code> untuk subjudul, <code>- </code> untuk daftar poin, atau <code>1. </code> untuk daftar angka.</p></details>' +
        '<details><summary>3. Mengatur kategori</summary><p>Di halaman Tulis, klik <b>✏️ Edit kategori</b> untuk menambah, mengubah nama, atau menghapus kategori. Semua kategori bisa diubah, dan menu di atas ikut menyesuaikan. Kalau sebuah kategori dihapus, tulisannya dipindah ke kategori lain.</p></details>' +
        '<details><summary>4. Menambah foto</summary><p>Pilih satu foto sampul dan sampai 6 foto pendukung. Foto otomatis dikecilkan supaya hemat tempat penyimpanan.</p></details>' +
        '<details><summary>5. Menambah lagu dan mode dramatis</summary><p>Unggah file audio (maksimal 15 MB) di halaman Tulis. Saat membuka tulisannya, tekan tombol ▶ untuk memutar lagu. Halaman akan berubah gelap dan bercahaya. Matikan lewat tombol mode dramatis kalau tidak mau.</p></details>' +
        '<details><summary>6. Membagikan tulisan</summary><p>Buka tulisanmu lalu klik <b>🔗 Salin link tulisan</b>, kirim linknya ke temanmu. Yang ikut terkirim hanya teksnya, tidak termasuk foto dan audio.</p></details>' +
        '<details><summary>7. Mengubah atau menghapus tulisan</summary><p>Buka tulisannya, lalu klik <b>✏️ Edit</b> atau <b>🗑️ Hapus</b> di bagian bawah. Daftar semua tulisanmu juga ada di menu Profil, bagian Tulisanku.</p></details>' +
        '<details><summary>8. Mengatur profil</summary><p>Di menu <b>Profil</b> kamu bisa mengisi nama panggilan, bio, dan memilih maskot. Nama panggilan ikut tampil di tulisan yang kamu bagikan.</p></details>' +
        '<details><summary>9. Mengamankan tulisan</summary><p>Tulisan tersimpan di browser perangkat ini. Kalau data browser dihapus, tulisannya ikut hilang, jadi simpan teks cadangan dari menu Profil bagian <b>Pengaturan &amp; cadangan</b> secara berkala. Cadangan tidak termasuk file audio.</p></details></div>' +
        '<div class="kotak"><h2>✍️ Contoh tulisan</h2><p>Mau mencoba langsung? Isi form Tulis dengan draft contoh yang bisa kamu ubah sesukamu.</p>' +
        '<button class="tombol utama" data-aksi="pakaiDraft">Pakai sebagai contoh tulisan</button></div>';
}
function tampilBantuan() { isiBantuan.innerHTML = bantuanHtml(); }
isiBantuan.addEventListener("click", function (e) {
    if (e.target.getAttribute("data-aksi") === "pakaiDraft") { draftAwal = DRAFT; location.hash = "#tulis"; }
});

// ===== Halaman profil =====
function tampilProfil() {
    var p = data.profil, milik = data.artikel.slice().sort(function (a, b) { return b.waktu - a.waktu; });
    var hitung = Object.create(null), fav = "-";
    milik.forEach(function (a) { hitung[a.kategori] = (hitung[a.kategori] || 0) + 1; });
    Object.keys(hitung).forEach(function (k) { if (fav === "-" || hitung[k] > hitung[fav]) fav = k; });
    var h = '<div class="profil-kepala"><div class="avatar">' + esc(p.avatar || "🐱") + "</div><div><h1>" + esc(p.nama || "Penulis baru") + "</h1>" +
        '<p class="meta">' + esc(p.bio || "Penulis di Jejak Harian") + "</p></div></div>" +
        '<div class="statistik"><div><b>' + milik.length + "</b>tulisan</div><div><b>" + esc(fav) + "</b>kategori favorit</div></div>";

    h += '<div class="kotak"><h2>Profilku</h2><label>Nama panggilan<input id="pNama" maxlength="40" value="' + esc(p.nama) + '"></label>' +
        '<label>Tentang aku<textarea id="pBio" rows="3" maxlength="200">' + esc(p.bio) + "</textarea></label>" +
        '<label>Maskot<select id="pAvatar">' + AVATAR.map(function (e) { return '<option' + (e === p.avatar ? " selected" : "") + ">" + e + "</option>"; }).join("") + "</select></label>" +
        '<button class="tombol utama" data-aksi="simpanProfil">Simpan profil</button></div>';

    h += '<div class="kotak"><h2>Tulisanku</h2>';
    if (!milik.length) h += '<p class="info">Belum ada tulisan. <a href="#tulis"><u>Mulai menulis</u></a></p>';
    milik.forEach(function (a) {
        h += '<div class="baris item"><a href="#artikel/' + a.id + '"><b>' + esc(a.judul) + '</b><span class="meta"> ' + esc(a.kategori) + ", " + esc(a.tanggal) + "</span></a>" +
            '<span><a class="tombol kecil" href="#tulis/' + a.id + '">Edit</a> <button class="tombol kecil bahaya" data-aksi="hapus" data-id="' + a.id + '">Hapus</button></span></div>';
    });
    h += "</div>";

    h += '<div class="kotak"><h2>Pengaturan &amp; cadangan</h2>' +
        '<p class="info">Tulisanmu tersimpan otomatis di browser perangkat ini. Untuk memindahkan semua tulisan ke perangkat lain, pakai cadangan di bawah.</p>' +
        '<div class="baris"><button class="tombol" data-aksi="ekspor">Tampilkan teks cadangan</button>' +
        '<label class="tombol">Pulihkan dari file<input type="file" id="pImpor" accept=".json" hidden></label></div>' +
        '<label>Teks cadangan<textarea id="pTempel" rows="3" placeholder="Teks cadangan muncul di sini, atau tempel teks cadanganmu lalu klik Pulihkan"></textarea></label>' +
        '<div class="baris"><button class="tombol kecil" data-aksi="imporTeks">Pulihkan dari teks</button></div>' +
        '<p class="petunjuk">Cadangan berisi teks dan foto, tidak termasuk file audio.</p></div>';

    h += '<div class="kotak teaser"><h2>❓ Butuh panduan?</h2><p>Lihat cara memakai Jejak Harian, lengkap dengan contoh tulisan.</p><a class="tombol" href="#bantuan">Buka Bantuan</a></div>';
    isiProfil.innerHTML = h;
}
function imporJson(teks) {
    try {
        var d = JSON.parse(teks), n = 0;
        (d.artikel || []).forEach(function (x) {
            var a = rapikan(x);
            if (daftarKat().indexOf(a.kategori) < 0) { if (data.kategoriList.length < MAKS_KAT) data.kategoriList.push(a.kategori); else a.kategori = "Catatan"; }
            if (!data.artikel.some(function (y) { return y.id === a.id; })) { data.artikel.push(a); n++; }
        });
        simpan(); renderMenu(); tampilProfil(); toast(n + " tulisan dipulihkan.");
    } catch (err) { toast("Teks cadangan tidak valid."); }
}
isiProfil.addEventListener("click", function (e) {
    var el = e.target.closest("[data-aksi]");
    if (!el) return;
    var aksi = el.getAttribute("data-aksi");
    if (aksi === "simpanProfil") {
        data.profil.nama = document.getElementById("pNama").value.trim();
        data.profil.bio = document.getElementById("pBio").value.trim();
        data.profil.avatar = document.getElementById("pAvatar").value;
        simpan(); perbaruiNavProfil(); tampilProfil();
        toast("Profil disimpan!");
    }
    else if (aksi === "ekspor") {
        var t = document.getElementById("pTempel"); t.value = JSON.stringify(data); t.focus(); t.select();
        toast("Teks cadangan sudah muncul di kotak. Salin lalu simpan di catatan atau emailmu.");
    }
    else if (aksi === "imporTeks") {
        imporJson(document.getElementById("pTempel").value);
    }
    else if (aksi === "hapus") hapusArtikel(el.getAttribute("data-id"), "#profil");
});
isiProfil.addEventListener("change", function (e) {
    if (e.target.id === "pImpor" && e.target.files[0]) {
        var r = new FileReader();
        r.onload = function () { imporJson(r.result); };
        r.readAsText(e.target.files[0]);
    }
});

// ===== Form tulis: handler =====
(function () {
    var k = document.getElementById("fKategori"), em = document.getElementById("fEmoji");
    em.innerHTML = EMOJI.concat(["📝"]).map(function (x) { return "<option>" + x + "</option>"; }).join("");
    document.getElementById("fCover").onchange = function () { if (this.files[0]) kecilkan(this.files[0], 1000, function (d) { tmp.cover = d; pratinjauFoto(); }); };
    document.getElementById("fExtra").onchange = function () {
        Array.prototype.slice.call(this.files, 0, 6 - tmp.extra.length).forEach(function (f) { kecilkan(f, 800, function (d) { if (tmp.extra.length < 6) { tmp.extra.push(d); pratinjauFoto(); } }); });
    };
    halaman.tulis.addEventListener("click", function (e) {
        var h = e.target.getAttribute("data-hapus");
        if (h === "audio") { tmp.audioBaru = null; tmp.audioHapus = true; document.getElementById("fAudio").value = ""; }
        else if (h === "cover") tmp.cover = ""; else if (h !== null) tmp.extra.splice(+h, 1); else return;
        pratinjauFoto();
    });
    document.getElementById("fAudio").onchange = function () {
        var f = this.files[0]; if (!f) return;
        if (f.size > 15 * 1024 * 1024) { toast("Audio terlalu besar (maksimal 15 MB)."); this.value = ""; return; }
        tmp.audioBaru = f; tmp.audioHapus = false;
        var n = document.getElementById("fAudioNama"); if (!n.value) n.value = f.name.replace(/\.[^.]+$/, "").slice(0, 80);
        pratinjauAudio();
    };
    var panel = document.getElementById("panelKat");
    function bukaPanel() { panel.hidden = false; tampilDaftarKat(); document.getElementById("katBaru").focus(); }
    document.getElementById("btnEditKat").onclick = function () { if (panel.hidden) bukaPanel(); else panel.hidden = true; };
    k.onchange = function () { if (k.value === "__baru") { k.value = katTerakhir; bukaPanel(); } else katTerakhir = k.value; };
    function tambahKat() {
        var inp = document.getElementById("katBaru");
        if (data.kategoriList.length >= MAKS_KAT) { toast("Maksimal " + MAKS_KAT + " kategori tambahan."); return; }
        var n = namaKatValid(inp.value, ""); if (!n) return;
        data.kategoriList.push(n); simpan(); inp.value = "";
        renderMenu(); isiPilihanKat(n); tampilDaftarKat(); toast("Kategori \"" + n + "\" ditambahkan.");
    }
    document.getElementById("btnTambahKat").onclick = tambahKat;
    document.getElementById("katBaru").onkeydown = function (e) { if (e.key === "Enter") tambahKat(); };
    panel.addEventListener("click", function (e) {
        var aksi = e.target.getAttribute("data-kat-aksi"); if (!aksi) return;
        var i = +e.target.getAttribute("data-i"), lama = data.kategoriList[i], pilihan = k.value;
        if (aksi === "ubah") {
            var n = namaKatValid(panel.querySelector('.katNama[data-i="' + i + '"]').value, lama); if (!n) return;
            data.kategoriList[i] = n;
            data.artikel.forEach(function (x) { if (x.kategori === lama) x.kategori = n; });
            if (pilihan === lama) pilihan = n;
            toast("Nama kategori diubah.");
        } else if (aksi === "hapus") {
            if (data.kategoriList.length < 2) { toast("Minimal harus ada satu kategori."); return; }
            if (!konfirmasi("kat" + i)) return;
            data.kategoriList.splice(i, 1);
            var cadangan = katAwal();
            data.artikel.forEach(function (x) { if (x.kategori === lama) x.kategori = cadangan; });
            if (pilihan === lama) pilihan = cadangan;
            toast("Kategori dihapus. Tulisannya dipindah ke " + cadangan + ".");
        }
        simpan(); renderMenu(); isiPilihanKat(pilihan); tampilDaftarKat();
    });
    document.getElementById("btnSimpan").onclick = simpanArtikel;
})();

// ===== Router sederhana berdasarkan hash URL =====
function router() {
    var bagian = (location.hash.replace("#", "") || "beranda").split("/"), h = bagian[0];
    nav.classList.remove("buka");
    hentikanAudio();
    Object.keys(halaman).forEach(function (k) { halaman[k].hidden = true; });
    document.title = "Jejak Harian - Blog Pribadi";
    if (h === "artikel") { halaman.artikel.hidden = false; tampilArtikel(bagian[1]); }
    else if (/^b\.[pz]\./.test(h)) { halaman.artikel.hidden = false; tandaiNav(""); tampilBagikan(h); }
    else if (h === "tulis") { halaman.tulis.hidden = false; tandaiNav("tulis"); tampilTulis(bagian[1]); }
    else if (h === "profil") { halaman.profil.hidden = false; tandaiNav("profil"); tampilProfil(); }
    else if (h === "bantuan") { halaman.bantuan.hidden = false; tandaiNav("bantuan"); tampilBantuan(); }
    else { halaman.beranda.hidden = false; var kat = h === "kategori" ? dekode(bagian[1] || "") : ""; tampilDaftar(daftarKat().indexOf(kat) >= 0 ? kat : "Semua"); }
    window.scrollTo(0, 0);
}

// Menu atas dan tombol filter dibuat dari daftar kategori
function renderMenu() {
    filter.innerHTML = "";
    semuaKat().forEach(function (k) {
        var b = document.createElement("button");
        b.className = "chip"; b.textContent = k;
        b.style.setProperty("--warna", k === "Semua" ? "#cdb0ff" : warnaKat(k)[0]);
        b.onclick = function () { location.hash = k === "Semua" ? "#beranda" : "#kategori/" + encodeURIComponent(k); };
        filter.appendChild(b);
    });
    nav.innerHTML = '<a href="#beranda" data-kat="semua">Beranda</a>' +
        daftarKat().map(function (k) { return '<a href="#kategori/' + encodeURIComponent(k) + '" data-kat="' + esc(k) + '">' + esc(k) + "</a>"; }).join("") +
        '<a href="#tulis" data-kat="tulis">✏️ Tulis</a><a href="#profil" data-kat="profil" id="navProfil">🐱 Profil</a><a href="#bantuan" data-kat="bantuan">❓ Bantuan</a>';
    perbaruiNavProfil();
}
renderMenu();
document.getElementById("menuBtn").onclick = function () { nav.classList.toggle("buka"); };

// Tombol kembali ke atas
var keAtas = document.getElementById("keAtas");
window.addEventListener("scroll", function () { keAtas.classList.toggle("tampil", window.scrollY > 400); });
keAtas.onclick = function () { window.scrollTo({ top: 0, behavior: "smooth" }); };

window.addEventListener("hashchange", router);
perbaruiNavProfil();
router();
